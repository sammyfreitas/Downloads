select avg(numfilhos) from senai.funcionarios;


/*ADICIONAR COLUNA
Alter table <nometabela>
	Add Column <nomecoluna> <tipodedado>;
    
Alter table funcionarios
	Add Column CTPS varchar(15);
    
Alter table funcionarios
	Modify	Column depto varchar(30);
    
 Alter table funcionarios
	Change Column depto departamento varchar(40);   

    change (renomear o nome da coluna/modificar o tipo de dado
    modify (modifica o tipo de dado / aumente a qtde de caracteres e etc
    


start transaction; /*(precaução para evitar executar um comando errado.

delete from funcionarios 
	where nomefunc='%Costa';
    
    commit; 			/*certeza que quer a execução*/
    rollback; 		/*(voltar a última ação*/

/*insert into curso (idcurso, nomeCurso,tipocurso) values
	(18,'VENDAS ONLINE','VENDAS');*/

/*delete from curso
	where tipocurso='vendas';*/