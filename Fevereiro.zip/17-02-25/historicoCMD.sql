USE SENAI;

/*media - AVG (AVERAGE) */
select avg(numfilhos) from funcionarios;  /*mostre a média de filhos na tabela funcionarios*/
select avg(salario) from funcionarios;    /*mostre a média de salario na tabela funcionarios*/

select avg(numfilhos) from funcionarios where depto="TI";

select avg(salario) from funcionarios where cargo like 'Engenheiro%';

select avg(numfilhos) from funcionarios where depto like '%Ges%';

select avg(salario) from funcionarios where nomefunc like '%Costa%';

