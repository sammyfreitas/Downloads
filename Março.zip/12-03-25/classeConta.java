import java.util.Date;


public class Conta {
    private int numConta;
    private String tipoConta;
    private Date dtAbertra;
    private int senha;
    private double saldo;
    
    public void AbrirConta(){
	    numConta = 1234;
	    System,out.println("Conta Aberta")
	    System,out.println("Número da Conta : ")
    }
	
	public void FecharConta(){
	   System,out.println("Conta Fechada")
	}
	
	public void Depositar(){
	}