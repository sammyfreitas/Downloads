public class Veiculo extends Moto {
	private string pedaleira;

	public void empinarMoto(){
        System.out.println("A moto empinou");
	}
} 