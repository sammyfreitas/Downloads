public class Veiculo extends Carro {
	private int numPortas;
	
	public void abrirPorta(){
		System.out.println("O veiculo abriu a porta");
	}
	public void abrirMala(){
		System.out.println("O veiculo abriu a mala");
	}

	public void abrirJanela(){
		System.out.println("O veiculo abriu a janela");
	}
}
