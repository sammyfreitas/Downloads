public class Veiculo extends Moto {
	private string pedaleira;

	public void empinarMoto(){

	}



} 

