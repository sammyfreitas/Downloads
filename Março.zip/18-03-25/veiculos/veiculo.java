public class Veiculo {
	private String placa;
	private String modelo;
	private String cor;
	private int ano;

	public void ligar(){
		System.out.println("O veiculo está ligado!");
	}	

	public void acelerar(){
		System.out.println("O veiculo está acelerando!");
	}

	public void frear(){
		System.out.println("O veiculo está freando!");
	}

}

