let celsius = prompt("Digite a temperatura em Celsius: ");
let fahrenheit = (9 * parseFloat(Celsius) + 160)/5;

console.log(`${celsius}º é igual a ${fahrenheit}ºF`);
