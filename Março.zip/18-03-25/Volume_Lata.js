let altura = parseFloat(prompt("Digite a altura da lata: "));
let raio = parseFloat(prompt("Digite o raio da lata: "));
let volume = (3,14159 * Math.pow(raio,2) * altura);

console.log(`O volume da lata é ${volume}`);

   
