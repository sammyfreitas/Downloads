let altura = parseFloat(prompt("Digite a altura da Caixa: "));
let comprimento = parseFloat(prompt("Digite o comprimento da Caixa: "));
let largura = parseFloat(prompt("Digite a largura da Caixa: "));
let volume = (comprimento * largura * altura);

// usar somente quando estiver testando um código //
console.log(`O volume da caixa retangular é ${volume}`); 

// usar somente quando estiver testando um código //
alert("O volume da caixa retangular é: " + volume);

   
