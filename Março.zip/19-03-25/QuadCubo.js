//Faça um algoritmo que leia um valor inteiro e apresente os resultados do
quadrado e do cubo do valor lido.

let num = parseFloat(prompt("Digite o número: "));
let quadrado = Math.pow(num, 2);
let cubo = Math.pow(num, 3); 

// usar somente quando estiver testando um código //
console.log(`O quadrado do ${num} é ${quadrado}.`); 
console.log(`O cubo do ${num} é ${cubo}.`); 



   
