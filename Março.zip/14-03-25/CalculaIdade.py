from datetime import datetime

print("OLÁ ALUNOS, VOU CALCULAR SUA IDADE!")
nome = input("DIGITE SEU NOME: ")
anonasc = int(input("DIGITE SEU ANO DE NASCIMENTO: "))
anoatual = datetime.now().year
idade = anoatual - anonasc
print(f"Olá, {nome}! Sua idade é {idade} anos")