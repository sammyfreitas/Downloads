import java.util.Scanner;
import java.time.Year;

public class CalculaIdade {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("OLA ALUNOS, VOU CALCULAR SUA IDADE!");
        System.out.println("DIGITE SEU NOME: ");
        String nome = scanner.nextLine();
        System.out.println("DIGITE SEU ANO DE NASCIMENTO: ");
        int anonasc = scanner.nextInt();
        int anoatual = Year.now().getValue();
        int idade = anoatual - anonasc;
        System.out.println("Ola, " + nome + "! Sua idade e " + idade + " anos");
        scanner.close();
    }
}