public class motor {
    
}
