public class veiculo {
    
}
