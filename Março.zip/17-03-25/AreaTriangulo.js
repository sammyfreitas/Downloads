console.log("--------------------------------");
console.log(" PROGRAMA PARA CALCULAR SOMA ");
console.log("--------------------------------");
let num1 = prompt("Digite um número: ");
let num2 = prompt("Digite outro número:  ");  
let soma = parseInt(num1) + parseInt(num2);
console.log(`A soma é: ${soma}.`);


function nome(){

}