let nome = prompt("Digite o nome: ");
let sobrenome = prompt("Digite o sobrenome:  ");  
console.log(`O nome completo é: ${nome} ${sobrenome}.`);