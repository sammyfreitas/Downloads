console.log("--------------------------------");
console.log(" PROGRAMA PARA SABER A IDADE ");
console.log("--------------------------------");
let nome = prompt("Qual é seu nome? ");
let ano = prompt("Qual é o ano do seu nascimento? ");  
let anoAtual = new Date().getFullYear();
let idade = anoAtual - parseInt(ano);
console.log(`Olá ${nome}, você tem ${idade} anos.`);